package com.amrita.cys21007.endsem;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class File {
    private String fileName;
    private long fileSize;

    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public void displayFileDetails() {
        System.out.println("File Name: " + fileName);
        System.out.println("File Size: " + fileSize + " bytes");
    }
}
class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    // Getters and setters
    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }


    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }
}
class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }


    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Resolution: " + resolution);
    }
}


class Video extends File {
    private String duration;

    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }


    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Duration: " + duration);
    }
}

// Interface
interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
}


class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }


    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        File fileToRemove = null;
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                fileToRemove = file;
                break;
            }
        }
        if (fileToRemove != null) {
            files.remove(fileToRemove);
            System.out.println("File '" + fileName + "' deleted.");
        } else {
            System.out.println("File '" + fileName + "' not found.");
        }
    }

    @Override
    public void displayAllFiles() {
        for (File file : files) {
            file.displayFileDetails();
            System.out.println();
        }
    }
}

class FileManagementSystemUI {
    private FileManagerImpl fileManager;
    private JFrame frame;
    private JTextField nameField;
    private JTextField sizeField;
    private JTextField typeResolutionField;
    private JTextField durationField;
    private JTable table;
    private DefaultTableModel tableModel;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        UI();
    }

    private void UI() {
        frame = new JFrame("File Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        panel.add(nameLabel);
        panel.add(nameField);

        JLabel sizeLabel = new JLabel("Size:");
        sizeField = new JTextField();
        panel.add(sizeLabel);
        panel.add(sizeField);

        JLabel typeResolutionLabel = new JLabel("Type/Resolution:");
        typeResolutionField = new JTextField();
        panel.add(typeResolutionLabel);
        panel.add(typeResolutionField);

        JLabel durationLabel = new JLabel("Duration:");
        durationField = new JTextField();
        panel.add(durationLabel);
        panel.add(durationField);

        JButton addButton = new JButton("Add File");
        addButton.addActionListener(e -> addFile());
        panel.add(addButton);

        JButton deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(e -> deleteFile());
        panel.add(deleteButton);

        JButton displayButton = new JButton("Display All Files");
        displayButton.addActionListener(e -> displayAllFiles());
        panel.add(displayButton);

        JButton saveButton = new JButton("Save to File");
        panel.add(saveButton);

        JButton loadButton = new JButton("Loading");
        panel.add(loadButton);


        table = new JTable();
        tableModel = new DefaultTableModel(new Object[]{"Name", "Size", "Type/Resolution"}, 0);
        table.setModel(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }

    private void addFile() {
        String name = nameField.getText();
        long size = Long.parseLong(sizeField.getText());
        String typeResolution = typeResolutionField.getText();
        String duration = durationField.getText();

        Image image = new Image(name, size, typeResolution);
        fileManager.addFile(image);

        Video video = new Video(name, size, duration);
        fileManager.addFile(video);

        Document document = new Document(name, size, typeResolution);
        fileManager.addFile(document);
        clearFormFields();
    }

    private void deleteFile() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            String fileName = (String) table.getValueAt(selectedRow, 0);
            fileManager.deleteFile(fileName);
        } else {
            JOptionPane.showMessageDialog(frame, "Select a file to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayAllFiles() {
        fileManager.displayAllFiles();
    }
    private void clearFormFields() {
        nameField.setText("");
        sizeField.setText("");
        typeResolutionField.setText("");
        durationField.setText("");
    }
}

// Main class
public class FileManagementSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(FileManagementSystemUI::new);
    }
}

